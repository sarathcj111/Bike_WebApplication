﻿using Bike_WebApplication.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System;
using System.Collections.Generic;
using System.Dynamic;
using System.IO;
using System.Reflection;
using System.Threading;


namespace Bike_WebApplication.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class WebApiCompanyController : Controller
    {
        private readonly IConfiguration _config;
        public WebApiCompanyController(IConfiguration config)
        {
            _config = config;
        }

        private List<CompanyModel> GenerateCompanyList()
        {
            var companyList = new List<CompanyModel>();
            for (var i = 0; i <= 100; i++)
            {
                if (_config.GetValue<int>($"Company{i + 1}:Id") > 0)
                {
                    CompanyModel company = new CompanyModel();
                    company.Id = _config.GetValue<int>($"Company{i + 1}:Id");
                    company.Name = _config.GetValue<string>($"Company{i + 1}:Name");
                    company.City = _config.GetValue<string>($"Company{i + 1}:City");
                    companyList.Add(company);
                }
                else
                    break;
            }
            return companyList;
        }

        [Route("getAllCompany")]
        [HttpGet]
        public IActionResult GetAllCompany()
        {
            try
            {
                var companyList = GenerateCompanyList();
                return Ok(JsonConvert.SerializeObject(companyList));
            }
            catch (Exception ex)
            {
                return StatusCode(503, new
                {
                    Message = "Failed to get the List",
                    Exception = new
                    {
                        Message = ex.Message,
                        StackTrace = ex.StackTrace
                    }
                });
            }
        }

        [Route("addCompany")]
        [HttpPost]
        public IActionResult AddCompany(CompanyModel company)
        {
            if (!ModelState.IsValid)
                return BadRequest("Invalid data.");
            var count = GenerateCompanyList().Count;
            company.Name = "api-" + company.Name;
            AddtoJson(company);
            Thread.Sleep(600);
            var count1 = GenerateCompanyList().Count;
            if (count1 - count == 1)
            {
                return Ok();
            }
            else
                return StatusCode(500);
        }

        [Route("editCompany")]
        [HttpPut]
        public IActionResult EditCompany(CompanyModel company)
        {
            if (!ModelState.IsValid)
                return BadRequest("Invalid data.");
            RemoveFromJson(company.Id, "Company");
            Thread.Sleep(600);
            AddtoJson(company);
            Thread.Sleep(600);
            return Ok(JsonConvert.SerializeObject(GenerateCompanyList()));
        }

        [Route("deleteCompany")]
        [HttpDelete]
        public IActionResult DeleteCompany()
        {
            if (!ModelState.IsValid)
                return BadRequest("Invalid data.");

            var companyId = HttpContext.Request.Query["companyid"];

            RemoveFromJson(Convert.ToInt32(companyId), "Company");
            Thread.Sleep(600);

            return Ok(JsonConvert.SerializeObject(GenerateCompanyList()));
        }
        public void AddtoJson<Object>(Object T)
        {
            var appSettingsPath = Path.Combine(System.IO.Directory.GetCurrentDirectory(), "appsettings.json");
            var json = System.IO.File.ReadAllText(appSettingsPath);

            var jsonSettings = new JsonSerializerSettings();
            jsonSettings.Converters.Add(new ExpandoObjectConverter());
            jsonSettings.Converters.Add(new StringEnumConverter());

            dynamic config = JsonConvert.DeserializeObject<ExpandoObject>(json, jsonSettings);

            dynamic newinput = JsonConvert.DeserializeObject<ExpandoObject>(JsonConvert.SerializeObject(T), jsonSettings);

            Type t = T.GetType();
            PropertyInfo[] props = t.GetProperties();

            var expando = config as IDictionary<string, object>;
            expando.Add($"{t.Name.Remove(t.Name.Length - 5)}{props[0].GetValue(T)}", newinput);

            var newJson = JsonConvert.SerializeObject(config, Formatting.Indented, jsonSettings);

            System.IO.File.WriteAllText(appSettingsPath, newJson);
        }

        public void RemoveFromJson(int Id, string type)
        {
            var appSettingsPath = Path.Combine(System.IO.Directory.GetCurrentDirectory(), "appsettings.json");
            var json = System.IO.File.ReadAllText(appSettingsPath);

            var jsonSettings = new JsonSerializerSettings();
            jsonSettings.Converters.Add(new ExpandoObjectConverter());
            jsonSettings.Converters.Add(new StringEnumConverter());

            dynamic config = JsonConvert.DeserializeObject<ExpandoObject>(json, jsonSettings);

            var expando = config as IDictionary<string, object>;
            expando.Remove($"{type}{Id}");

            var newJson = JsonConvert.SerializeObject(config, Formatting.Indented, jsonSettings);

            System.IO.File.WriteAllText(appSettingsPath, newJson);
        }
    }
}
