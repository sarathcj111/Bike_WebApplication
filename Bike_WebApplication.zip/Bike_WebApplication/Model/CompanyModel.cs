﻿namespace Bike_WebApplication.Model
{
    public class CompanyModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string City { get; set; }
    }
}
