﻿using Bike_WebApplication.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System;
using System.Collections.Generic;
using System.Dynamic;
using System.IO;
using System.Reflection;
using System.Threading;


namespace WebApplication_Bike.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class WebApiBikeController : Controller
    {
        private readonly IConfiguration _config;
        public WebApiBikeController(IConfiguration config)
        {
            _config = config;
        }

        private List<BikeModel> GenerateBikeList()
        {
            var bikeList = new List<BikeModel>();
            for (var i = 0; i <= 100; i++)
            {
                if (_config.GetValue<int>($"Bike{i + 1}:Id") > 0)
                {
                    BikeModel bike = new BikeModel();
                    bike.Id = _config.GetValue<int>($"Bike{i + 1}:Id");
                    bike.Company = _config.GetValue<string>($"Bike{i + 1}:Company");
                    bike.Model = _config.GetValue<string>($"Bike{i + 1}:Model");
                    bike.Price = _config.GetValue<decimal>($"Bike{i + 1}:Price");
                    bikeList.Add(bike);
                }
                else
                    break;
            }
            return bikeList;
        }

        [Route("getAllBikes")]
        [HttpGet]
        public IActionResult GetAllBikes()
        {
            var bikeList = GenerateBikeList();
            return Ok(JsonConvert.SerializeObject(bikeList));
        }

        [Route("addBike")]
        [HttpPost]
        public IActionResult AddBike(BikeModel bike)
        {
            if (!ModelState.IsValid)
                return BadRequest("Invalid data.");
            var count = GenerateBikeList().Count;
            bike.Model = "api-" + bike.Model;
            AddtoJson(bike);
            Thread.Sleep(600);
            var count1 = GenerateBikeList().Count;
            if (count1 - count == 1)
            {
                return Ok();
            }
            else
                return StatusCode(500);
        }

        [Route("editBike")]
        [HttpPut]
        public IActionResult EditBike(BikeModel bike)
        {
            if (!ModelState.IsValid)
                return BadRequest("Invalid data.");
            RemoveFromJson(bike.Id, "Bike");
            Thread.Sleep(600);
            AddtoJson(bike);
            Thread.Sleep(600);
            return Ok(JsonConvert.SerializeObject(GenerateBikeList()));
        }

        [Route("deleteBike")]
        [HttpDelete]
        public IActionResult DeleteBike()
        {
            if (!ModelState.IsValid)
                return BadRequest("Invalid data.");
            var bikeId = HttpContext.Request.Query["bikeid"];
            RemoveFromJson(Convert.ToInt32(bikeId), "Bike");
            Thread.Sleep(600);
            return Ok(JsonConvert.SerializeObject(GenerateBikeList()));
        }


        //LOGIN
        private List<UserModel> GenerateUserList()
        {
            var userList = new List<UserModel>();
            for (var i = 0; i <= 100; i++)
            {
                if (_config.GetValue<int>($"User{i + 1}:Id") > 0)
                {
                    UserModel user = new UserModel();
                    user.Id = _config.GetValue<int>($"User{i + 1}:Id");
                    user.Username = _config.GetValue<string>($"User{i + 1}:userName");
                    user.Password = _config.GetValue<string>($"User{i + 1}:Password");
                    userList.Add(user);
                }
                else
                    break;
            }
            return userList;
        }

        [Route("verifyUser")]    // To verify the credentials while login
        [HttpPost]
        public IActionResult VerifyUser(UserModel user)
        {
            if (!ModelState.IsValid)
                return BadRequest("Invalid data.");

            var userList = GenerateUserList();
            var isValidUser = userList.Find(x => x.Username == user.Username && x.Password == user.Password)?.Id > 0 ? true : false;

            if (isValidUser)
                return Ok();
            else
                return StatusCode(401);
        }
         
        [Route("registerUser")]     //To register new user 
        [HttpPost]
        public IActionResult RegisterUser(RegisterUserModel regUser)
        {
            if (!ModelState.IsValid)
                return BadRequest("Invalid data.");

            var userList = GenerateUserList();
            var count = userList.Count;
            var userFound = userList.FindAll(x => x.Username == regUser.Username);   //Checking weather the username already exists or not

            if (userFound.Count > 0)
                return StatusCode(403, new
                {
                    message = "Username Already Exist",
                    userName = regUser.Username
                });

            var user = new UserModel();
            user.Id = userList.Count + 1;
            user.Username = regUser.Username;
            user.Password = regUser.Password;

            AddtoJson(user);
            Thread.Sleep(600);

            var count1 = GenerateUserList().Count;
            if (count1 - count == 1)
            {
                return Ok();
            }
            else
                return StatusCode(500);
        }

        [Route("userNameAvailability")]    //Cheking weather the username already exists or not
        [HttpGet]
        public IActionResult UserNameAvailability(string name)
        {
            var userList = GenerateUserList();
            var userFound = userList.FindAll(x => x.Username == name);

            if (userFound.Count > 0)
                return StatusCode(403, new
                {
                    message = "Username Already Exist",
                    userName = name
                });
            else
                return Ok();

        }



        // Add and Remove from json
        public void AddtoJson<Object>(Object T)
        {
            var appSettingsPath = Path.Combine(System.IO.Directory.GetCurrentDirectory(), "appsettings.json");
            var json = System.IO.File.ReadAllText(appSettingsPath);

            var jsonSettings = new JsonSerializerSettings();
            jsonSettings.Converters.Add(new ExpandoObjectConverter());
            jsonSettings.Converters.Add(new StringEnumConverter());

            dynamic config = JsonConvert.DeserializeObject<ExpandoObject>(json, jsonSettings);

            dynamic newinput = JsonConvert.DeserializeObject<ExpandoObject>(JsonConvert.SerializeObject(T), jsonSettings);

            Type t = T.GetType();
            PropertyInfo[] props = t.GetProperties();

            var expando = config as IDictionary<string, object>;
            expando.Add($"{t.Name.Remove(t.Name.Length - 5)}{props[0].GetValue(T)}", newinput);

            var newJson = JsonConvert.SerializeObject(config, Formatting.Indented, jsonSettings);

            System.IO.File.WriteAllText(appSettingsPath, newJson);
        }

        public void RemoveFromJson(int Id, string type)
        {
            var appSettingsPath = Path.Combine(System.IO.Directory.GetCurrentDirectory(), "appsettings.json");
            var json = System.IO.File.ReadAllText(appSettingsPath);

            var jsonSettings = new JsonSerializerSettings();
            jsonSettings.Converters.Add(new ExpandoObjectConverter());
            jsonSettings.Converters.Add(new StringEnumConverter());

            dynamic config = JsonConvert.DeserializeObject<ExpandoObject>(json, jsonSettings);

            var expando = config as IDictionary<string, object>;
            expando.Remove($"{type}{Id}");

            var newJson = JsonConvert.SerializeObject(config, Formatting.Indented, jsonSettings);

            System.IO.File.WriteAllText(appSettingsPath, newJson);
        }

    }
}



