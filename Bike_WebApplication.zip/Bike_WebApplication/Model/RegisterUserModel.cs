﻿namespace Bike_WebApplication.Model
{
    public class RegisterUserModel
    {
        public string Username { get; set; }

        public string Password { get; set; }

        public string ConfirmPassword { get; set; }
    }
}
// To register new user with new userename and password